import displayStryktipsData from "./display_results.js";

function init(){
    displayStryktipsData()
}
window.addEventListener('load', init)